@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 9.2.1 is required. Install Gradle and Java 21, then run this file again.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 exit /b 1
echo.
echo Build complete. JAR files are in build\libs
pause
