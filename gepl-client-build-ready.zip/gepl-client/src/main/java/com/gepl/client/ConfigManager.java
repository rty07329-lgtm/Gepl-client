package com.gepl.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Per-instance persistent module configuration. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private ConfigManager() {}
    private static Path path() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("gepl-client.json");
    }
    public static void load() {
        Path file = path();
        if (!Files.exists(file)) { save(); return; }
        try {
            JsonObject root = GSON.fromJson(Files.readString(file), JsonObject.class);
            if (root == null || !root.has("modules") || !root.get("modules").isJsonObject()) return;
            JsonObject modules = root.getAsJsonObject("modules");
            for (Module module : ModuleManager.all()) {
                if (modules.has(module.id()) && modules.get(module.id()).isJsonPrimitive())
                    module.setEnabled(modules.get(module.id()).getAsBoolean());
            }
        } catch (Exception e) {
            System.err.println("[GePL] Config load failed: " + e.getMessage());
        }
    }
    public static void save() {
        try {
            Path file = path(); Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject(); root.addProperty("configVersion", 1);
            JsonObject modules = new JsonObject();
            for (Module module : ModuleManager.all()) modules.addProperty(module.id(), module.enabled());
            root.add("modules", modules);
            Path temp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(root));
            try { Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException unsupportedAtomicMove) { Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) {
            System.err.println("[GePL] Config save failed: " + e.getMessage());
        }
    }
}
