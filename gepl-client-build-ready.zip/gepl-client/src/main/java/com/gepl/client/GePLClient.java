package com.gepl.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class GePLClient implements ClientModInitializer {
    public static final String MOD_ID="gepl";
    private static KeyMapping openGui;
    @Override public void onInitializeClient() {
        ConfigManager.load();
        KeyMapping.Category category=KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID,"main"));
        openGui=KeyBindingHelper.registerKeyBinding(new KeyMapping("key.gepl.open_gui",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_RIGHT_SHIFT,category));
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            while(openGui.consumeClick()) if(client.screen==null) client.setScreen(new GePLScreen());
            if(client.player!=null) {
                Module sprint=ModuleManager.get("Sprint Assist");
                if(sprint.enabled()&&client.player.input.hasForwardImpulse()&&!client.player.isCrouching()&&!client.player.isUsingItem()) client.player.setSprinting(true);
            }
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client->ConfigManager.save());
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,Identifier.fromNamespaceAndPath(MOD_ID,"gepl_hud"),GePLClient::renderHud);
    }
    private static void renderHud(net.minecraft.client.gui.GuiGraphics g,net.minecraft.client.DeltaTracker tickCounter) {
        Minecraft mc=Minecraft.getInstance();
        if(!ModuleManager.get("HUD").enabled()||mc.player==null||mc.options.hideGui) return;
        if(ModuleManager.get("Clean Screens").enabled()&&mc.screen!=null) return;
        int x=9,y=9,panelWidth=170,rows=0;
        if(ModuleManager.get("FPS").enabled()) rows++;
        if(ModuleManager.get("Coordinates").enabled()) rows++;
        if(ModuleManager.get("Ping").enabled()) rows++;
        if(ModuleManager.get("Clock").enabled()) rows++;
        if(ModuleManager.get("Direction").enabled()) rows++;
        if(ModuleManager.get("Item Durability").enabled()&&mc.player.getMainHandItem().isDamageableItem()) rows++;
        if(ModuleManager.get("Armor Status").enabled()) rows++;
        int height=21+rows*12+6;
        g.fill(x-5,y-5,x+panelWidth,y+height,0xD9141005); g.fill(x-5,y-5,x+panelWidth,y-3,0xFFFFC629);
        if(ModuleManager.get("Watermark").enabled()) { g.drawString(mc.font,"GePL",x,y,0xFFFFD65A,false); g.drawString(mc.font,"SYSTEM  /  CLIENT",x+55,y+1,0xFFD5C18A,false); }
        y+=17;
        if(ModuleManager.get("FPS").enabled()) { line(g,"FPS",Integer.toString(mc.getFps()),x,y); y+=12; }
        if(ModuleManager.get("Coordinates").enabled()) { var p=mc.player; line(g,"XYZ",String.format(java.util.Locale.ROOT,"%.1f  %.1f  %.1f",p.getX(),p.getY(),p.getZ()),x,y); y+=12; }
        if(ModuleManager.get("Ping").enabled()&&mc.getConnection()!=null&&mc.getConnection().getPlayerInfo(mc.player.getUUID())!=null) { line(g,"PING",mc.getConnection().getPlayerInfo(mc.player.getUUID()).getLatency()+" ms",x,y); y+=12; }
        if(ModuleManager.get("Clock").enabled()) { line(g,"TIME",LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")),x,y); y+=12; }
        if(ModuleManager.get("Direction").enabled()) { line(g,"FACING",mc.player.getDirection().getName().toUpperCase(java.util.Locale.ROOT),x,y); y+=12; }
        if(ModuleManager.get("Item Durability").enabled()&&mc.player.getMainHandItem().isDamageableItem()) { int left=mc.player.getMainHandItem().getMaxDamage()-mc.player.getMainHandItem().getDamageValue(); line(g,"ITEM",left+" durability",x,y); y+=12; }
        if(ModuleManager.get("Armor Status").enabled()) { int count=0; for(var stack:mc.player.getArmorSlots()) if(!stack.isEmpty()) count++; line(g,"ARMOR",count+"/4 equipped",x,y); }
    }
    private static void line(net.minecraft.client.gui.GuiGraphics g,String label,String value,int x,int y) {
        var mc=Minecraft.getInstance(); g.drawString(mc.font,label,x,y,0xFFD5C18A,false); g.drawString(mc.font,value,x+58,y,0xFFF2EDF8,false);
    }
}
