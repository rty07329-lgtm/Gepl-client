package com.gepl.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class GePLScreen extends Screen {
    private Module.Category selected = Module.Category.HUD;
    private static final int GOLD = 0xFFFFC83D;
    private static final int GOLD_BRIGHT = 0xFFFFE08A;
    private static final int PANEL = 0xF00D0B08;
    private static final int SIDEBAR = 0xF0141009;
    private static final int TILE = 0xFF1D180F;
    private static final int TILE_HOVER = 0xFF30230D;
    private static final int TEXT = 0xFFFFF4DC;
    private static final int MUTED = 0xFFB9AA88;
    private static final int LINE = 0xFF59431A;

    private int scroll;
    private String search = "";
    private boolean searchFocused;

    public GePLScreen() { super(Component.literal("GePL Client")); }

    private int panelWidth() { return Math.min(790, width - 24); }
    private int panelHeight() { return Math.min(470, height - 24); }
    private int left() { return (width - panelWidth()) / 2; }
    private int top() { return (height - panelHeight()) / 2; }
    private int navWidth() { return 126; }
    private int infoWidth() { return 158; }
    private int contentLeft() { return left() + navWidth() + 16; }
    private int contentRight() { return left() + panelWidth() - infoWidth() - 25; }
    private int contentTop() { return top() + 88; }
    private int contentBottom() { return top() + panelHeight() - 35; }

    private List<Module> visibleModules() {
        List<Module> result = new ArrayList<>();
        String q = search.toLowerCase(Locale.ROOT);
        for (Module module : ModuleManager.byCategory(selected)) {
            if (q.isEmpty() || module.name().toLowerCase(Locale.ROOT).contains(q)
                    || module.description().toLowerCase(Locale.ROOT).contains(q)) {
                result.add(module);
            }
        }
        return result;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int l = left(), t = top(), w = panelWidth(), h = panelHeight();
        int nav = navWidth(), info = infoWidth();
        int right = l + w;

        // Main frame and premium gold trim.
        g.fill(l, t, right, t + h, PANEL);
        g.fill(l, t, right, t + 2, GOLD);
        g.fill(l, t + 2, l + nav, t + h, SIDEBAR);
        g.fill(l, t + 2, l + 1, t + h, 0xFF8A641C);

        // Top brand bar.
        g.drawString(font, "♛", l + 15, t + 13, GOLD_BRIGHT, false);
        g.drawString(font, "GePL CLIENT", l + 38, t + 10, TEXT, false);
        g.drawString(font, "SYSTEM DLC  /  GOLD EDITION", l + 38, t + 25, GOLD, false);

        int searchX = l + nav + 18;
        int searchW = Math.max(130, w - nav - info - 85);
        g.fill(searchX, t + 10, searchX + searchW, t + 39, 0xFF100D08);
        g.fill(searchX, t + 10, searchX + searchW, t + 11, searchFocused ? GOLD : LINE);
        g.fill(searchX, t + 38, searchX + searchW, t + 39, LINE);
        g.drawString(font, "⌕", searchX + 10, t + 17, GOLD, false);
        String searchText = search.isEmpty() ? "Search modules..." : search;
        g.drawString(font, searchText, searchX + 29, t + 19,
                search.isEmpty() ? MUTED : TEXT, false);
        g.drawString(font, "—", right - 39, t + 17, GOLD_BRIGHT, false);
        g.drawString(font, "×", right - 20, t + 16, GOLD_BRIGHT, false);

        // Navigation rail.
        g.fill(l + 10, t + 48, l + nav - 10, t + 49, LINE);
        String[] labels = {"HUD", "VISUAL", "PLAYER", "MISC"};
        Module.Category[] categories = Module.Category.values();
        int navY = t + 63;
        for (int i = 0; i < categories.length; i++) {
            boolean active = selected == categories[i];
            int y = navY + i * 35;
            if (active) {
                g.fill(l + 8, y - 6, l + nav - 8, y + 20, 0xFF3B2A0B);
                g.fill(l + 8, y - 6, l + 11, y + 20, GOLD);
            }
            String icon = switch (categories[i]) {
                case HUD -> "▣";
                case VISUAL -> "◉";
                case PLAYER -> "◆";
                case MISC -> "⚙";
            };
            g.drawString(font, icon, l + 18, y, active ? GOLD_BRIGHT : MUTED, false);
            g.drawString(font, labels[i], l + 39, y, active ? TEXT : MUTED, false);
        }

        g.fill(l + 10, t + h - 48, l + nav - 10, t + h - 47, LINE);
        g.drawString(font, "CONFIGS", l + 18, t + h - 35, MUTED, false);
        g.drawString(font, "GePL v1.1", l + 18, t + h - 19, GOLD, false);

        // Main module area.
        int cx = contentLeft(), cr = contentRight();
        g.drawString(font, selected.name() + "  /  MODULES", cx, t + 55, TEXT, false);
        g.drawString(font, "Select a module to toggle it", cx, t + 69, MUTED, false);
        g.fill(cx, t + 82, cr, t + 83, LINE);

        List<Module> modules = visibleModules();
        int gap = 9;
        int tileW = Math.max(100, (cr - cx - gap) / 2);
        int tileH = 43;
        int rowGap = 8;
        int startY = contentTop() - scroll;

        g.enableScissor(cx, contentTop(), cr, contentBottom());
        for (int i = 0; i < modules.size(); i++) {
            Module module = modules.get(i);
            int col = i % 2;
            int row = i / 2;
            int x = cx + col * (tileW + gap);
            int y = startY + row * (tileH + rowGap);
            if (y + tileH >= contentTop() && y <= contentBottom()) {
                boolean hover = mouseX >= x && mouseX <= x + tileW
                        && mouseY >= y && mouseY <= y + tileH;
                g.fill(x, y, x + tileW, y + tileH, hover ? TILE_HOVER : TILE);
                g.fill(x, y, x + tileW, y + 1, module.enabled() ? GOLD : LINE);
                g.drawString(font, module.name(), x + 9, y + 7, TEXT, false);
                String desc = module.description();
                int maxChars = Math.max(12, (tileW - 68) / 6);
                if (desc.length() > maxChars) desc = desc.substring(0, maxChars - 1) + "…";
                g.drawString(font, desc, x + 9, y + 22, MUTED, false);

                int sx = x + tileW - 39;
                g.fill(sx, y + 14, sx + 29, y + 29,
                        module.enabled() ? 0xFF9A6B0D : 0xFF49402D);
                int knob = module.enabled() ? sx + 17 : sx + 3;
                g.fill(knob, y + 16, knob + 9, y + 27, 0xFFFFF7E7);
            }
        }
        g.disableScissor();

        // Right-side client information card.
        int ix = cr + 13;
        int ir = right - 13;
        int iy = t + 52;
        int ib = t + h - 32;
        g.fill(ix, iy, ir, ib, 0xFF100D08);
        g.fill(ix, iy, ir, iy + 1, GOLD);
        g.drawString(font, "♛", ix + 52, iy + 16, GOLD_BRIGHT, false);
        g.drawString(font, "GePL CLIENT", ix + 17, iy + 43, TEXT, false);
        g.drawString(font, "GOLD EDITION", ix + 27, iy + 57, GOLD, false);
        g.fill(ix + 10, iy + 76, ir - 10, iy + 77, LINE);
        g.drawString(font, "CLIENT INFO", ix + 10, iy + 88, GOLD_BRIGHT, false);
        g.drawString(font, "Minecraft 1.21.11", ix + 10, iy + 105, MUTED, false);
        g.drawString(font, "Fabric Edition", ix + 10, iy + 120, MUTED, false);
        g.fill(ix + 10, iy + 141, ir - 10, iy + 142, LINE);
        g.drawString(font, "MODULES", ix + 10, iy + 153, GOLD_BRIGHT, false);
        int enabled = 0;
        for (Module module : ModuleManager.all()) if (module.enabled()) enabled++;
        g.drawString(font, enabled + " ENABLED", ix + 10, iy + 170, TEXT, false);
        g.drawString(font, "CONFIG", ix + 10, iy + 196, GOLD_BRIGHT, false);
        g.drawString(font, "Auto-save: ON", ix + 10, iy + 213, MUTED, false);
        g.drawString(font, "Right Shift", ix + 10, ib - 28, GOLD, false);
        g.drawString(font, "Open / close menu", ix + 10, ib - 15, MUTED, false);

        // Footer strip.
        g.fill(l + nav + 14, t + h - 22, right - 13, t + h - 21, LINE);
        g.drawString(font, "GePL CLIENT  •  SETTINGS SAVED AUTOMATICALLY",
                l + nav + 18, t + h - 14, MUTED, false);

        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int l = left(), t = top(), nav = navWidth(), w = panelWidth();
        int searchX = l + nav + 18;
        int searchW = Math.max(130, w - nav - infoWidth() - 85);
        searchFocused = mouseX >= searchX && mouseX <= searchX + searchW
                && mouseY >= t + 10 && mouseY <= t + 39;

        String[] labels = {"HUD", "VISUAL", "PLAYER", "MISC"};
        Module.Category[] categories = Module.Category.values();
        int navY = t + 63;
        for (int i = 0; i < categories.length; i++) {
            int y = navY + i * 35;
            if (mouseX >= l + 8 && mouseX <= l + nav - 8
                    && mouseY >= y - 6 && mouseY <= y + 20) {
                selected = categories[i];
                scroll = 0;
                return true;
            }
        }

        int cx = contentLeft(), cr = contentRight();
        int gap = 9, tileW = Math.max(100, (cr - cx - gap) / 2);
        int tileH = 43, rowGap = 8, startY = contentTop() - scroll;
        List<Module> modules = visibleModules();
        for (int i = 0; i < modules.size(); i++) {
            int col = i % 2, row = i / 2;
            int x = cx + col * (tileW + gap);
            int y = startY + row * (tileH + rowGap);
            if (mouseX >= x && mouseX <= x + tileW && mouseY >= y && mouseY <= y + tileH
                    && mouseY >= contentTop() && mouseY <= contentBottom()) {
                modules.get(i).toggle();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (searchFocused && !Character.isISOControl(codePoint)) {
            search += codePoint;
            scroll = 0;
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchFocused && keyCode == 259) {
            if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
            scroll = 0;
            return true;
        }
        if (keyCode == 256 && searchFocused) {
            searchFocused = false;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY,
                                 double horizontalAmount, double verticalAmount) {
        int rows = (visibleModules().size() + 1) / 2;
        int contentHeight = rows * (43 + 8);
        int max = Math.max(0, contentHeight - (contentBottom() - contentTop()));
        scroll = Math.max(0, Math.min(max, scroll - (int)(verticalAmount * 25)));
        return true;
    }

    @Override public boolean isPauseScreen() { return false; }
}
