package com.gepl.client;

public final class Module {
    private final String name;
    private final String description;
    private final Category category;
    private final String id;
    private boolean enabled;

    public Module(String name, String description, Category category, boolean enabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
        this.id = name.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_|_$", "");
    }
    public String name() { return name; }
    public String id() { return id; }
    public String description() { return description; }
    public Category category() { return category; }
    public boolean enabled() { return enabled; }
    public void toggle() { enabled = !enabled; ConfigManager.save(); }
    public void setEnabled(boolean value) { enabled = value; }
    public enum Category { HUD, VISUAL, PLAYER, MISC }
}
