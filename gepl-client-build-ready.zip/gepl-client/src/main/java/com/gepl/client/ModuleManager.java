package com.gepl.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    static {
        MODULES.add(new Module("HUD", "Master switch for the GePL overlay", Module.Category.HUD, true));
        MODULES.add(new Module("FPS", "Display current frame rate", Module.Category.HUD, true));
        MODULES.add(new Module("Coordinates", "Display your XYZ position", Module.Category.HUD, true));
        MODULES.add(new Module("Ping", "Display connection latency", Module.Category.HUD, true));
        MODULES.add(new Module("Clock", "Display local time", Module.Category.HUD, false));
        MODULES.add(new Module("Direction", "Display the direction you are facing", Module.Category.HUD, false));
        MODULES.add(new Module("Armor Status", "Display equipped armor count", Module.Category.HUD, false));
        MODULES.add(new Module("Item Durability", "Display held item durability", Module.Category.HUD, true));
        MODULES.add(new Module("Watermark", "Show the GePL label", Module.Category.VISUAL, true));
        MODULES.add(new Module("Clean Screens", "Hide overlay while a screen is open", Module.Category.VISUAL, false));
        MODULES.add(new Module("Particles", "Show or hide ambient particles preference", Module.Category.VISUAL, true));
        MODULES.add(new Module("Low Fire", "Low first-person fire overlay preference", Module.Category.VISUAL, false));
        MODULES.add(new Module("Clear Water", "Water visibility preference", Module.Category.VISUAL, false));
        MODULES.add(new Module("Sprint Assist", "Use vanilla sprint when moving forward", Module.Category.PLAYER, false));
        MODULES.add(new Module("Toggle Sneak", "Remember toggle-sneak preference", Module.Category.PLAYER, false));
        MODULES.add(new Module("Notifications", "Show module state notifications preference", Module.Category.MISC, true));
        MODULES.add(new Module("Module List", "Show enabled module names preference", Module.Category.MISC, false));
    }
    private ModuleManager() {}
    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }
    public static Module get(String name) {
        return MODULES.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    public static List<Module> byCategory(Module.Category category) {
        return MODULES.stream().filter(m -> m.category() == category).toList();
    }
}
